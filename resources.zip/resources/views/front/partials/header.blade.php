@php
    use Illuminate\Support\Facades\Storage;
    $currentLocale  = app()->getLocale();
    $flagSvgs = [
        'fr' => '<svg width="20" height="14" viewBox="0 0 20 14" xmlns="http://www.w3.org/2000/svg" style="border-radius:2px;display:inline-block;vertical-align:middle;flex-shrink:0;"><rect width="7" height="14" fill="#002395"/><rect x="7" width="6" height="14" fill="#fff"/><rect x="13" width="7" height="14" fill="#ED2939"/></svg>',
        'pt' => '<svg width="20" height="14" viewBox="0 0 20 14" xmlns="http://www.w3.org/2000/svg" style="border-radius:2px;display:inline-block;vertical-align:middle;flex-shrink:0;"><rect width="8" height="14" fill="#006600"/><rect x="8" width="12" height="14" fill="#CC0000"/><circle cx="8" cy="7" r="3.5" fill="#FFD700" stroke="#006600" stroke-width=".5"/></svg>',
        'en' => '<svg width="20" height="14" viewBox="0 0 20 14" xmlns="http://www.w3.org/2000/svg" style="border-radius:2px;display:inline-block;vertical-align:middle;flex-shrink:0;"><rect width="20" height="14" fill="#012169"/><path d="M0,0 L20,14 M20,0 L0,14" stroke="#fff" stroke-width="2.8"/><path d="M0,0 L20,14 M20,0 L0,14" stroke="#C8102E" stroke-width="1.5"/><path d="M10,0 V14 M0,7 H20" stroke="#fff" stroke-width="4"/><path d="M10,0 V14 M0,7 H20" stroke="#C8102E" stroke-width="2.5"/></svg>',
    ];
    $locales = ['fr' => 'fr', 'pt' => 'pt', 'en' => 'en'];

    // Génère une URL pour la même page dans une autre locale
    $routeName      = request()->route()?->getName() ?? 'front.home';
    $routeParams    = request()->route()?->parameters() ?? [];
    $switchLocale   = fn(string $locale) => route($routeName, array_merge($routeParams, ['locale' => $locale]));
@endphp

{{-- Sticky Header --}}
<sticky-header data-sticky-type="always">
    <header class="header-1 header-floating">
        <div class="container-fluid">
            <div class="header-grid">
                <a class="header-logo d-flex align-items-center gap-2" href="{{ route('front.home', ['locale' => $currentLocale]) }}" aria-label="{{ $settings->company_name ?? 'EYWEP' }}">
                    @if ($settings->company_logo_path)
                        <img
                            src="{{ Storage::url($settings->company_logo_path) }}"
                            alt="{{ $settings->company_name }}"
                            class="eywep-dynamic-logo"
                        >
                    @else
                        <img
                            src="{{ asset('front-assets/consulo/img/logo-white.png') }}"
                            alt="{{ $settings->company_name ?? 'EYWEP' }}"
                            width="189"
                            height="32"
                        >
                    @endif
                    <span class="eywep-brand-name d-none d-sm-inline">{{ $settings->company_name ?? 'EYWEP' }}</span>
                    @if (file_exists(public_path('images/partners/logo-ua.png')))
                        <span class="eywep-partner-separator d-none d-md-block"></span>
                        <img
                            src="{{ asset('images/partners/logo-ua.png') }}"
                            alt="Union Africaine"
                            class="eywep-partner-logo d-none d-md-block"
                        >
                    @endif
                </a>

                <drawer-menu>
                    <nav class="header-nav drawer-menu">
                        <div class="d-lg-none header-nav-headings">
                            <a class="header-logo" href="{{ route('front.home', ['locale' => $currentLocale]) }}" aria-label="{{ $settings->company_name ?? 'EYWEP' }}">
                                @if ($settings->company_logo_path)
                                    <img
                                        src="{{ Storage::url($settings->company_logo_path) }}"
                                        alt="{{ $settings->company_name }}"
                                        class="eywep-dynamic-logo"
                                        loading="lazy"
                                    >
                                @else
                                    <img
                                        src="{{ asset('front-assets/consulo/img/logo.png') }}"
                                        alt="{{ $settings->company_name ?? 'EYWEP' }}"
                                        width="189"
                                        height="32"
                                        loading="lazy"
                                    >
                                @endif
                            </a>
                            <drawer-opener
                                class="svg-wrapper menu-close"
                                data-drawer=".drawer-menu"
                            >
                                <svg
                                    width="30px"
                                    height="30px"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                >
                                    <path
                                        d="M8.00386 9.41816C7.61333 9.02763 7.61334 8.39447 8.00386 8.00395C8.39438 7.61342 9.02755 7.61342 9.41807 8.00395L12.0057 10.5916L14.5907 8.00657C14.9813 7.61605 15.6144 7.61605 16.0049 8.00657C16.3955 8.3971 16.3955 9.03026 16.0049 9.42079L13.4199 12.0058L16.0039 14.5897C16.3944 14.9803 16.3944 15.6134 16.0039 16.0039C15.6133 16.3945 14.9802 16.3945 14.5896 16.0039L12.0057 13.42L9.42097 16.0048C9.03045 16.3953 8.39728 16.3953 8.00676 16.0048C7.61624 15.6142 7.61624 14.9811 8.00676 14.5905L10.5915 12.0058L8.00386 9.41816Z"
                                        fill="currentColor"
                                    />
                                    <path
                                        fill-rule="evenodd"
                                        clip-rule="evenodd"
                                        d="M23 12C23 18.0751 18.0751 23 12 23C5.92487 23 1 18.0751 1 12C1 5.92487 5.92487 1 12 1C18.0751 1 23 5.92487 23 12ZM3.00683 12C3.00683 16.9668 7.03321 20.9932 12 20.9932C16.9668 20.9932 20.9932 16.9668 20.9932 12C20.9932 7.03321 16.9668 3.00683 12 3.00683C7.03321 3.00683 3.00683 7.03321 3.00683 12Z"
                                        fill="currentColor"
                                    />
                                </svg>
                            </drawer-opener>
                        </div>

                        <ul class="header-menu list-unstyled">
                            <li class="nav-item">
                                <a href="{{ route('front.home', ['locale' => $currentLocale]) }}" class="menu-link menu-link-main">{{ __('app.nav.home') }}</a>
                            </li>
                            <li class="nav-item">
                                <a class="menu-link menu-link-main menu-accrodion" href="#">
                                    {{ __('app.nav.publications') }}
                                    <svg width="10" height="5" viewBox="0 0 10 5" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M5 5L0 0H10L5 5Z" fill="currentColor"/>
                                    </svg>
                                </a>
                                <div class="menu-absolute header-submenu submenu-color">
                                    <ul class="list-unstyled">
                                        <li class="nav-item"><a class="menu-link" href="{{ route('front.articles.index', ['locale' => $currentLocale]) }}">{{ __('app.nav.articles') }}</a></li>
                                        <li class="nav-item"><a class="menu-link" href="{{ route('front.activities.index', ['locale' => $currentLocale]) }}">{{ __('app.nav.activities') }}</a></li>
                                        <li class="nav-item"><a class="menu-link" href="{{ route('front.success-stories.index', ['locale' => $currentLocale]) }}">{{ __('app.nav.testimonials') }}</a></li>
                                        <li class="nav-item"><a class="menu-link" href="{{ route('front.resources.index', ['locale' => $currentLocale]) }}">{{ __('app.nav.resources') }}</a></li>
                                    </ul>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('front.galleries.index', ['locale' => $currentLocale]) }}" class="menu-link menu-link-main">{{ __('app.nav.galleries') }}</a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('front.projects.index', ['locale' => $currentLocale]) }}" class="menu-link menu-link-main">{{ __('app.nav.projects') }}</a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('front.about', ['locale' => $currentLocale]) }}" class="menu-link menu-link-main">{{ __('app.nav.about') }}</a>
                            </li>
                            <li class="nav-item">
                                <a href="{{ route('front.contact', ['locale' => $currentLocale]) }}" class="menu-link menu-link-main">{{ __('app.nav.contact') }}</a>
                            </li>
                        </ul>
                    </nav>
                </drawer-menu>

                <div class="header-actions d-flex align-items-center gap-2">

                    {{-- Bouton recherche --}}
                    <drawer-opener
                        class="header-search search-open svg-wrapper me-2"
                        data-drawer=".modal-search"
                        aria-label="{{ __('app.search.aria') }}"
                        style="cursor:pointer;"
                    >
                        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M21.71 20.29L18 16.61A9 9 0 1 0 16.61 18l3.68 3.68a1 1 0 0 0 1.42-1.39zM11 18a7 7 0 1 1 7-7 7 7 0 0 1-7 7z" fill="currentColor"/>
                        </svg>
                    </drawer-opener>

                    {{-- Sélecteur de langue --}}
                    <div class="eywep-lang-switcher dropdown">
                        <button
                            class="button button--secondary eywep-lang-btn dropdown-toggle"
                            type="button"
                            data-bs-toggle="dropdown"
                            aria-expanded="false"
                            style="padding: 6px 12px; font-size: 13px; min-width: 0;"
                        >
                            {!! $flagSvgs[$currentLocale] !!}
                            {{ strtoupper($currentLocale) }}
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end eywep-lang-menu">
                            @foreach ($locales as $locale => $code)
                                @if ($locale !== $currentLocale)
                                    <li>
                                        <a
                                            class="dropdown-item d-flex align-items-center gap-2"
                                            href="{{ $switchLocale($locale) }}"
                                        >
                                            {!! $flagSvgs[$locale] !!}
                                            {{ __('app.lang.' . $locale) }}
                                        </a>
                                    </li>
                                @endif
                            @endforeach
                        </ul>
                    </div>

                    <a href="{{ route('login') }}" class="button button--secondary" aria-label="{{ __('app.nav.login') }}">
                        <span class="d-none d-sm-inline">{{ __('app.nav.login') }}</span>
                        <span class="svg-wrapper">
                            <svg class="icon-20" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M13.3365 7.84518L6.16435 15.0173L4.98584 13.8388L12.158 6.66667H5.83652V5H15.0032V14.1667H13.3365V7.84518Z" fill="currentColor"/>
                            </svg>
                        </span>
                    </a>
                    <drawer-opener
                        class="header-sidebar svg-wrapper d-lg-none ms-3"
                        data-drawer=".drawer-menu"
                    >
                        <svg
                            width="30px"
                            height="30px"
                            viewBox="0 0 24 24"
                            fill="none"
                            xmlns="http://www.w3.org/2000/svg"
                        >
                            <path d="M4 6H20M4 12H20M4 18H20" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
                        </svg>
                    </drawer-opener>
                </div>
            </div>
        </div>
    </header>

    {{-- Modal Search --}}
    <modal-search class="theme-modal modal-search">
        <div class="modal-container">
            <div class="modal-header">
                <drawer-opener
                    class="svg-wrapper search-close"
                    data-drawer=".modal-search"
                    aria-label="{{ __('app.search.close') }}"
                    style="cursor:pointer;"
                >
                    <svg width="30px" height="30px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M8.00386 9.41816C7.61333 9.02763 7.61334 8.39447 8.00386 8.00395C8.39438 7.61342 9.02755 7.61342 9.41807 8.00395L12.0057 10.5916L14.5907 8.00657C14.9813 7.61605 15.6144 7.61605 16.0049 8.00657C16.3955 8.3971 16.3955 9.03026 16.0049 9.42079L13.4199 12.0058L16.0039 14.5897C16.3944 14.9803 16.3944 15.6134 16.0039 16.0039C15.6133 16.3945 14.9802 16.3945 14.5896 16.0039L12.0057 13.42L9.42097 16.0048C9.03045 16.3953 8.39728 16.3953 8.00676 16.0048C7.61624 15.6142 7.61624 14.9811 8.00676 14.5905L10.5915 12.0058L8.00386 9.41816Z" fill="currentColor"/>
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M23 12C23 18.0751 18.0751 23 12 23C5.92487 23 1 18.0751 1 12C1 5.92487 5.92487 1 12 1C18.0751 1 23 5.92487 23 12ZM3.00683 12C3.00683 16.9668 7.03321 20.9932 12 20.9932C16.9668 20.9932 20.9932 16.9668 20.9932 12C20.9932 7.03321 16.9668 3.00683 12 3.00683C7.03321 3.00683 3.00683 7.03321 3.00683 12Z" fill="currentColor"/>
                    </svg>
                </drawer-opener>
            </div>
            <div class="modal-main d-flex align-items-center justify-content-center">
                <form
                    action="{{ route('front.search', ['locale' => $currentLocale]) }}"
                    method="GET"
                    class="form-search d-flex align-items-center justify-content-center flex-wrap"
                >
                    <label for="modal-search-input" class="text text-30">{{ __('app.search.label') }}</label>
                    <input
                        type="text"
                        placeholder="{{ __('app.search.placeholder') }}"
                        name="q"
                        id="modal-search-input"
                        class="text text-16"
                        autocomplete="off"
                    >
                    <button class="button button--primary" type="submit" aria-label="{{ __('app.search.submit') }}">
                        <span class="svg-wrapper">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M21.71 20.29L18 16.61A9 9 0 1 0 16.61 18l3.68 3.68a1 1 0 0 0 1.42-1.39zM11 18a7 7 0 1 1 7-7 7 7 0 0 1-7 7z" fill="currentColor"/>
                            </svg>
                        </span>
                    </button>
                </form>
            </div>
        </div>
    </modal-search>

</sticky-header>
