@php
    use Illuminate\Support\Facades\Storage;
    $stats = __('app.about.stats');
    $mvv   = __('app.about.mvv');
    $aboutBullets = __('app.about.bullets');
@endphp
@extends('front.layouts.app')

@section('title', ($settings->company_name ?? 'EYWEP') . ' - ' . __('app.titles.about'))
@section('description', __('app.about.lead'))

@section('content')
<main>

    @include('front.partials.page-banner', ['bannerTitle' => __('app.pages.about')])

    @php
        $heroImgs   = $settings->hero_images ?? [];
        $aboutImage = !empty($heroImgs)
            ? Storage::url($heroImgs[0])
            : asset('front-assets/consulo/img/slider/hero-1.jpg');
    @endphp

    {{-- INTRO --}}
    <section class="py-5">
        <div class="container">
            <div class="row align-items-center g-4">
                <div class="col-lg-6">
                    <img src="{{ $aboutImage }}" alt="{{ __('app.about.section_label') }} EYWEP" loading="eager"
                        class="radius18 w-100" style="height:auto;">
                </div>
                <div class="col-lg-6">
                    <div class="section-headings mb-3">
                        <div class="subheading text-20 subheading-bg">
                            <svg class="icon icon-14" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none">
                                <path d="M8.71401 5.28599C11.7514 5.4205 14 5.9412 14 7C14 8.0588 11.7514 8.5795 8.71401 8.71401C8.5795 11.7514 8.0588 14 7 14C5.9412 14 5.4205 11.7514 5.28599 8.71401C2.2486 8.5795 0 8.0588 0 7C0 5.94119 2.2486 5.4205 5.28599 5.28599C5.4205 2.2486 5.9412 0 7 0C8.0588 0 8.5795 2.2486 8.71401 5.28599Z" fill="currentColor"/>
                            </svg>
                            {{ __('app.about.section_label') }}
                        </div>
                        <h1 class="heading text-50 fw-700">
                            {{ __('app.about.title', ['name' => $settings->company_name ?? 'EYWEP']) }}
                        </h1>
                    </div>
                    <p class="text text-18 mb-2 fw-500">{{ __('app.about.lead') }}</p>
                    <p class="text text-16 mb-3" style="color:var(--color-foreground-subheading);">{{ __('app.about.body') }}</p>
                    <ul class="list-unstyled mb-3" style="display:flex; flex-direction:column; gap:10px;">
                        @foreach ($aboutBullets as $i => $bullet)
                        <li class="d-flex align-items-start gap-2">
                            <svg style="flex-shrink:0; margin-top:2px; width:22px; height:22px; color:var(--color-primary);" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <defs><clipPath id="chk-about-{{ $i }}"><rect width="28" height="28" fill="white"/></clipPath></defs>
                                <g clip-path="url(#chk-about-{{ $i }})">
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M8.81362 13.0268C8.34112 12.7113 7.70994 12.783 7.31911 13.196C6.92886 13.6084 6.89211 14.2431 7.23336 14.6975L10.7334 19.3642C10.9445 19.6453 11.2712 19.8168 11.6229 19.8303C11.9741 19.8431 12.313 19.6972 12.5446 19.4324L20.7113 10.0991C21.1144 9.63883 21.0928 8.94525 20.6623 8.51008C20.2318 8.07492 19.5388 8.04692 19.0739 8.44475L11.5786 14.8696L8.81362 13.0268Z" fill="white"/>
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M13.9327 0.515625C6.52939 0.515625 0.519531 6.52549 0.519531 13.9288C0.519531 21.3321 6.52939 27.3419 13.9327 27.3419C21.336 27.3419 27.3458 21.3321 27.3458 13.9288C27.3458 6.52549 21.336 0.515625 13.9327 0.515625ZM13.9327 1.68166C20.6921 1.68166 26.1798 7.16938 26.1798 13.9288C26.1798 20.6882 20.6921 26.1759 13.9327 26.1759C7.17329 26.1759 1.68557 20.6882 1.68557 13.9288C1.68557 7.16938 7.17329 1.68166 13.9327 1.68166Z" fill="currentColor"/>
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M9.13872 12.5389C8.42939 12.0658 7.48265 12.1731 6.89698 12.792C6.31073 13.4115 6.25648 14.363 6.76806 15.0449L10.2681 19.7115C10.5848 20.1339 11.0748 20.3905 11.6021 20.4104C12.1295 20.4302 12.6376 20.2109 12.9852 19.8142L21.1519 10.4809C21.7562 9.78965 21.7241 8.74956 21.0784 8.0974C20.4326 7.44465 19.3926 7.40205 18.6961 7.99938L11.5356 14.1366L9.13872 12.5389ZM8.4918 13.5096L11.2562 15.3529C11.4738 15.4976 11.7608 15.4801 11.9597 15.3103L19.455 8.88547C19.6871 8.68597 20.0342 8.70055 20.2495 8.91814C20.4647 9.13514 20.4752 9.48222 20.274 9.71264L12.1073 19.046C11.9912 19.1778 11.8221 19.2513 11.6459 19.2443C11.4703 19.2379 11.307 19.1521 11.2014 19.0116L7.7014 14.3449C7.53106 14.1174 7.54913 13.8006 7.74455 13.5941C7.93938 13.3876 8.25497 13.3521 8.4918 13.5096Z" fill="currentColor"/>
                                </g>
                            </svg>
                            <span class="text text-16">{{ $bullet }}</span>
                        </li>
                        @endforeach
                    </ul>
                    <a href="{{ route('front.contact') }}" class="button button--primary">
                        {{ __('app.btn.contact_us') }}
                        <span class="svg-wrapper">
                            <svg class="icon-20" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                <path d="M13.3365 7.84518L6.16435 15.0173L4.98584 13.8388L12.158 6.66667H5.83652V5H15.0032V14.1667H13.3365V7.84518Z" fill="currentColor"/>
                            </svg>
                        </span>
                    </a>
                </div>
            </div>
        </div>
    </section>

    {{-- PARTENAIRES (défilement) --}}
    @if ($partners->isNotEmpty())
    @php $sponsorList = $partners->all(); @endphp
    <section class="section-sponsors py-5" style="background:#fff; overflow:hidden;">
        <div class="container mb-4">
            <div class="section-headings text-center">
                <div class="subheading text-20 subheading-bg d-inline-flex">
                    <svg class="icon icon-14" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none">
                        <path d="M8.71401 5.28599C11.7514 5.4205 14 5.9412 14 7C14 8.0588 11.7514 8.5795 8.71401 8.71401C8.5795 11.7514 8.0588 14 7 14C5.9412 14 5.4205 11.7514 5.28599 8.71401C2.2486 8.5795 0 8.0588 0 7C0 5.94119 2.2486 5.4205 5.28599 5.28599C5.4205 2.2486 5.9412 0 7 0C8.0588 0 8.5795 2.2486 8.71401 5.28599Z" fill="currentColor"/>
                    </svg>
                    {{ __('app.about.partners_label') }}
                </div>
            </div>
        </div>
        <div class="sponsors-track-wrapper" style="position:relative;">
            <div style="pointer-events:none;position:absolute;top:0;left:0;width:120px;height:100%;background:linear-gradient(to right,#fff,transparent);z-index:2;"></div>
            <div style="pointer-events:none;position:absolute;top:0;right:0;width:120px;height:100%;background:linear-gradient(to left,#fff,transparent);z-index:2;"></div>
            <div class="sponsors-track d-flex align-items-center gap-5" style="width:max-content;">
                @foreach (array_merge($sponsorList, $sponsorList, $sponsorList, $sponsorList) as $partner)
                <div class="sponsor-item flex-shrink-0 text-center px-3">
                    @if ($partner->lien)
                        <a href="{{ $partner->lien }}" target="_blank" rel="noopener noreferrer" class="sponsor-link" title="{{ $partner->titre }}">
                    @endif
                    @if ($partner->logo_path)
                        <img src="{{ Storage::url($partner->logo_path) }}" alt="{{ $partner->titre }}" loading="lazy" class="sponsor-logo">
                    @else
                        <span class="fw-600 text-16" style="color:var(--color-foreground-subheading);white-space:nowrap;">{{ $partner->titre }}</span>
                    @endif
                    @if ($partner->lien)
                        </a>
                    @endif
                </div>
                @endforeach
            </div>
        </div>
        <style>
            @keyframes sponsors-scroll {
                from { transform: translateX(0); }
                to   { transform: translateX(-25%); }
            }
            .sponsors-track { animation: sponsors-scroll 15s linear infinite; }
            .sponsors-track-wrapper:hover .sponsors-track { animation-play-state: paused; }
            @media (prefers-reduced-motion: reduce) { .sponsors-track { animation: none !important; } }
            .sponsor-logo { max-height:70px; max-width:160px; object-fit:contain; filter:grayscale(60%); opacity:.8; transition:filter .3s,opacity .3s,transform .3s; }
            .sponsor-item:hover .sponsor-logo { filter:grayscale(0); opacity:1; transform:scale(1.05); }
            .sponsor-link { display:inline-block; text-decoration:none; }
        </style>
    </section>
    @endif

    {{-- COUNTER UP --}}
    <counter-up class="counter-up d-block mt-40">
        <div class="container">
            <div class="counter-up-box radius18">
                <div class="row product-grid text-center">
                    @foreach ($stats as $i => $stat)
                    <div class="col-12 col-md-3" data-aos="fade-up" @if($i > 0) data-aos-delay="{{ $i * 100 }}" @endif>
                        <div class="counter-item">
                            <h2 class="heading text-50" data-target="{{ $stat['target'] }}">0<span>{{ $stat['suffix'] }}</span></h2>
                            <div class="text text-18 fw-500">{{ $stat['label'] }}</div>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
    </counter-up>

    {{-- MISSION / VISION / VALEURS --}}
    <section class="py-5 mt-40" style="background:#f8f9fa;">
        <div class="container">
            <div class="section-headings text-center mb-40">
                <div class="subheading text-20 subheading-bg">
                    <svg class="icon icon-14" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none">
                        <path d="M8.71401 5.28599C11.7514 5.4205 14 5.9412 14 7C14 8.0588 11.7514 8.5795 8.71401 8.71401C8.5795 11.7514 8.0588 14 7 14C5.9412 14 5.4205 11.7514 5.28599 8.71401C2.2486 8.5795 0 8.0588 0 7C0 5.94119 2.2486 5.4205 5.28599 5.28599C5.4205 2.2486 5.9412 0 7 0C8.0588 0 8.5795 2.2486 8.71401 5.28599Z" fill="currentColor"/>
                    </svg>
                    {{ __('app.about.mvv_label') }}
                </div>
                <h2 class="heading text-50 fw-700">{{ __('app.about.mvv_title') }}</h2>
            </div>
            <div class="row g-3">
                @foreach ($mvv as $item)
                <div class="col-md-4">
                    <div class="radius18 p-4 h-100" style="background:#fff; border:1px solid rgba(0,0,0,.06);">
                        <div class="mb-3" style="width:48px; height:48px; border-radius:10px; background:var(--color-primary); display:flex; align-items:center; justify-content:center;">
                            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="color:#fff;">{!! $item['icon'] !!}</svg>
                        </div>
                        <h3 class="heading text-20 fw-700 mb-2">{{ $item['title'] }}</h3>
                        <p class="text text-15 mb-0" style="color:var(--color-foreground-subheading);">{{ $item['text'] }}</p>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </section>

    {{-- FAQ --}}
    <div class="faq section-padding" style="margin-top: 30px;">
        <div class="container">
            <div class="row faq-row">
                <div class="col-lg-6 col-12">
                    <div class="section-headings">
                        <div class="subheading text-20 subheading-bg" data-aos="fade-up">
                            <svg class="icon icon-14" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none">
                                <g clip-path="url(#clip-faq-about-a)">
                                    <path d="M8.71401 5.28599C11.7514 5.4205 14 5.9412 14 7C14 8.0588 11.7514 8.5795 8.71401 8.71401C8.5795 11.7514 8.0588 14 7 14C5.9412 14 5.4205 11.7514 5.28599 8.71401C2.2486 8.5795 -1.33117e-07 8.0588 0 7C4.62818e-08 5.94119 2.2486 5.4205 5.28599 5.28599C5.4205 2.2486 5.9412 0 7 0C8.0588 0 8.5795 2.2486 8.71401 5.28599Z" fill="CurrentColor"/>
                                </g>
                                <defs><clipPath id="clip-faq-about-a"><rect width="14" height="14" fill="CurrentColor"/></clipPath></defs>
                            </svg>
                            <span>{{ __('app.about.faq_label') }}</span>
                            <svg class="icon icon-14" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14" fill="none">
                                <g clip-path="url(#clip-faq-about-b)">
                                    <path d="M8.71401 5.28599C11.7514 5.4205 14 5.9412 14 7C14 8.0588 11.7514 8.5795 8.71401 8.71401C8.5795 11.7514 8.0588 14 7 14C5.9412 14 5.4205 11.7514 5.28599 8.71401C2.2486 8.5795 -1.33117e-07 8.0588 0 7C4.62818e-08 5.94119 2.2486 5.4205 5.28599 5.28599C5.4205 2.2486 5.9412 0 7 0C8.0588 0 8.5795 2.2486 8.71401 5.28599Z" fill="CurrentColor"/>
                                </g>
                                <defs><clipPath id="clip-faq-about-b"><rect width="14" height="14" fill="CurrentColor"/></clipPath></defs>
                            </svg>
                        </div>
                        <h2 class="heading text-50" data-aos="fade-up" data-aos-delay="50">
                            {{ __('app.about.faq_title') }}
                        </h2>
                        <div class="text text-18" data-aos="fade-up" data-aos-delay="80">
                            {{ __('app.about.faq_subtitle') }}
                        </div>
                        <div class="buttons" data-aos="fade-up" data-aos-delay="100">
                            <a href="{{ route('front.contact') }}" class="button button--primary" aria-label="{{ __('app.btn.ask_question') }}">
                                {{ __('app.btn.ask_question') }}
                                <span class="svg-wrapper">
                                    <svg class="icon-20" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M13.3365 7.84518L6.16435 15.0173L4.98584 13.8388L12.158 6.66667H5.83652V5H15.0032V14.1667H13.3365V7.84518Z" fill="CurrentColor"/>
                                    </svg>
                                </span>
                            </a>
                        </div>
                        <div class="image-absolute" data-aos="zoom-in">
                            <img src="{{ asset('front-assets/consulo/img/faq/question.png') }}" width="104" height="180" loading="lazy" alt="Question">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-12">
                    <faq-accordion>
                        <div class="accordion-list">
                            @forelse ($faqs as $faq)
                            <div class="accordion-block" data-aos="fade-up" @if(!$loop->first) data-aos-delay="{{ $loop->index * 50 }}" @endif>
                                <div class="accordion-opener heading text-22">
                                    {{ $faq->question }}
                                    <div class="svg-wrapper">
                                        <svg class="icon icon-24" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <g clip-path="url(#clip-faq-about-chevron)">
                                                <path fill-rule="evenodd" clip-rule="evenodd" d="M12.7083 15.7044C12.5208 15.8919 12.2665 15.9972 12.0013 15.9972C11.7362 15.9972 11.4818 15.8919 11.2943 15.7044L5.63732 10.0474C5.54181 9.95517 5.46563 9.84482 5.41322 9.72282C5.36081 9.60081 5.33322 9.46959 5.33207 9.33681C5.33092 9.20404 5.35622 9.07236 5.4065 8.94946C5.45678 8.82656 5.53103 8.71491 5.62492 8.62102C5.71882 8.52713 5.83047 8.45287 5.95337 8.40259C6.07626 8.35231 6.20794 8.32701 6.34072 8.32816C6.4735 8.32932 6.60472 8.3569 6.72672 8.40931C6.84873 8.46172 6.95907 8.5379 7.05132 8.63341L12.0013 13.5834L16.9513 8.63341C17.1399 8.45125 17.3925 8.35046 17.6547 8.35274C17.9169 8.35502 18.1677 8.46019 18.3531 8.64559C18.5385 8.831 18.6437 9.08182 18.646 9.34401C18.6483 9.60621 18.5475 9.85881 18.3653 10.0474L12.7083 15.7044Z" fill="CurrentColor"/>
                                            </g>
                                            <defs><clipPath id="clip-faq-about-chevron"><rect width="24" height="24" fill="CurrentColor"/></clipPath></defs>
                                        </svg>
                                    </div>
                                </div>
                                <div class="accordion-content">
                                    <div class="accordion-content-inner text text-18">
                                        {{ $faq->reponse }}
                                    </div>
                                </div>
                            </div>
                            @empty
                            <p class="text text-18" style="color:var(--color-foreground-subheading);">{{ __('app.about.faq_empty') }}</p>
                            @endforelse
                        </div>
                    </faq-accordion>
                </div>
            </div>
        </div>
    </div>

</main>
@endsection
